$(function () {

  var api_key = "s0pTecret666";// I know.

  var allowCustomInput = false;
  if (typeof allow_custominput !== "undefined") {
    allowCustomInput = allow_custominput;
  }

  var questionID = question_id;
  var groupquestionID = groupquestion_id;
  var teamID = team_id;
  var sessionID = session_id;

  var storagePostfix = "";
  if (groupquestionID) {
    storagePostfix = "grq_" + groupquestionID;
  } else if (questionID) {
    storagePostfix = "que_" + questionID;
  }

  var modalContainer = null;
  var modalDialog = null;
  var customInputElement = null;
  var checkboxCustomSubmission = null;

  showQuestion();
  var editor = startCodeMirror();

  //Will become true if showQuestion is successful
  var UIReady = false;
  var openDetails = false;
  var finished = false;

  var refreshInterval = setInterval(function() {
    if (!UIReady) return;

    if (openDetails) return;

    if (finished) return;

    listSubmissions();
  }, 2000);


  var blockedUntilTS = null;
  var submissionsBlockedUntil = localStorage.getItem("submissionsBlockedUntil" + storagePostfix);
  if (submissionsBlockedUntil) {
    blockedUntilTS = parseInt(submissionsBlockedUntil);
  }

  var submitButtonLock = setInterval(function() {
    if (finished && (blockedUntilTS === null || blockedUntilTS <= Date.now())){
      $('#codeGrader-subRes').hide();
      $('.cdgrdr-btn-submit[type="button"]').attr("disabled", false);
    }
  }, 300);

  /**
   * POST /admin/api/submission/{question_id}
   */
  function doSubmission(customInput) {
    if(!editor.getValue()) return;

    finished = false;

    localStorage.setItem("compiler", $('select#compiler').val());

    $('.cdgrdr-btn-submit[type="button"]').attr('disabled', true);


    var submissionData = {
      sourcecode: editor.getValue(),
      compiler: $('#compiler').val()
    };

    if (allowCustomInput && checkboxCustomSubmission.is(":checked")) {
      submissionData.custom_testcase = customInput;
    }

    $.ajax({
      type: "POST",
      url: "/admin/api/submission/" + questionID,
      contentType: "application/json",
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
        "groupquestionID": groupquestionID|'null',
        "teamID": teamID|'null'
      },
      data: JSON.stringify(submissionData),
      success: function(result){
        var f = $('#codeGrader-subRes');
        f.hide();


        if (result.type == 'error') {
          f.html(result.message);
          f.show();
        }
      },
      error: function(result) {
        var f = $('#codeGrader-subRes');
        f.hide();

        if (result.status === 429) {
          f.html("Too many requests, please try again in a minute.");
          f.show();
          blockedUntilTS = Date.now() + 60000;
          localStorage.setItem("submissionsBlockedUntil" + storagePostfix, blockedUntilTS.toString());
        }
      }
    })
    .done(function() {
      listSubmissions();
    });
  }

  function showQuestion() {
    $.ajax({
      url: "/admin/api/question/" + questionID,
      contentType: "application/json",
      dataType: "json",
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
      },
      success: function(result) {

        var f = $('<div></div>').attr('id', 'codeGrader-container').addClass('codeGrader');
        $('#answerform').append(f);

        var compilerCont = $('#answerform');

        if (result.error) {
          f.prepend($('<div>').addClass('warning').html(result.error));
        } else {
          var l = $('<label for="compiler">');
          l.html('Compiler');
          var s = $('<select></select>').attr('id', 'compiler').change(function(){
            setEditorMode();
          });
          $.each(result.compilers, function(key,compiler) {
            o = $('<option></option>')
              .val(compiler.id)
              .html(compiler.name)
              .data({'mimetype': compiler.mimetype});
            s.append(o);
          });
          compilerCont.prepend(s);
          compilerCont.prepend(l);

          if (s.find(`option[value="${localStorage.getItem("compiler")}"]`)) {
            s.val(localStorage.getItem("compiler"));
          }

          f.append(
            $('<input>').attr('type','button').addClass("cdgrdr-btn-submit")
              .val('Submit').on("click", function (event) {
                event.stopPropagation();

                if ($('#compiler').val() === null) {
                  alert("Please select a compiler before you submit.");
                  return;
                }

                if (allowCustomInput) {
                  localStorage.setItem("customInput" + storagePostfix, customInputElement.val());
                }

                if (allowCustomInput && checkboxCustomSubmission.is(":checked")) {
                  doSubmission(customInputElement.val());
                } else {
                  doSubmission();
                }
              })
          );

          if (allowCustomInput) {
            f.append($('<span style="margin-left: 5px;">Custom</span>'));

            checkboxCustomSubmission = $('<input type="checkbox" />').on("click", function () {
              customInputElement.toggle();
            });
            f.append(checkboxCustomSubmission);


            var cont = $('<div style="margin-top: 10px;"></div>');
            customInputElement = $('<textarea spellcheck="false" style="display: none; width: 100%;" rows="4"></textarea>');
            if (localStorage.getItem("customInput" + storagePostfix) !== null) {
              customInputElement.val(localStorage.getItem("customInput" + storagePostfix));
            }

            cont.append(customInputElement);
            f.append(cont);
          }

          f.append($('<div></div>').attr('id', 'codeGrader-subRes').addClass('warning').css('color', 'red').hide());

          // If you exceed the submissions per minute and get blocked, remember it on refreshing the page.
          if (blockedUntilTS !== null && blockedUntilTS >= Date.now()){
            $('.cdgrdr-btn-submit[type="button"]').attr("disabled", true);
            var outputEl = $('#codeGrader-subRes');
            outputEl.html("Too many requests, please try again in a minute.");
            outputEl.show();
          }

          modalContainer = $('<div></div>').attr({
            'id': 'codeGrader-modal',
            'title': 'Results'
          }).addClass('codeGrader');
          modalDialog = modalContainer.dialog({
            autoOpen: false,
            modal: true,
            minWidth: 600,
            open: function() {
              openDetails = true;
            },
            close: function() {
              openDetails = false;
            }
          });

          UIReady = true;
        }
        listSubmissions();
        setEditorMode();
      }
    });
  }

  function getSubmissionDate(date) {
    // s = submission date
    var sDay = new Date(date);
    var sDayBefore = new Date(date);
    sDayBefore.setDate(sDayBefore.getDate() - 1);
    var today = new Date();
    var yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    if(today.getDate() === sDay.getDate() && today.getMonth() === sDay.getMonth() && today.getFullYear() === sDay.getFullYear()) {
      return "Today " + sDay.toLocaleTimeString();
    }else if(yesterday.getDate() === sDayBefore.getDate() && yesterday.getMonth() === sDayBefore.getMonth() && yesterday.getFullYear() === sDayBefore.getFullYear()) {
      return "Yesterday " + sDay.toLocaleTimeString();
    }else{
      return sDay.toLocaleDateString() + " " + sDay.toLocaleTimeString();
    }
  }

  /**
   * GET /admin/api/submissions/{question_id}
   */
  function listSubmissions() {
    $.ajax({
      type: "GET",
      url: "/admin/api/submissions/" + questionID,
      contentType: "application/json",
      dataType: "json",
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
        "groupquestionID": groupquestionID|'null',
        "teamID": teamID|'null'
      },
      success: function(result) {
        var inProgress = false;
        $.each(result, function (key, obj) {
          if (obj.Status === "Waiting" || obj.Status === "Compiling" || obj.Status === "Evaluating") {
            inProgress = true;
          }
        });

        if(!inProgress) {
          finished = true;
        }


        $('#submissions').remove();

        var f = $('#codeGrader-container');
        var d = $('<div></div>').attr('id', 'submissions');
        f.append(d);

        if (result.warning) {
          d.prepend($('<div></div>').addClass('warning').html(result.warning));
        } else {

          var t = $('<table></table>').addClass('submissions');
          var r = $('<tr></tr>');
          var headers = ['Date', 'File name', 'Score', 'Status', 'Compiler', ''];
          $.each(headers, function(key, val){
            r.append($('<th></th>').html(val));
          });
          t.append(r);
          $.each(result, function(key, obj) {
            r = $('<tr></tr>');

            r.append($('<td></td>').attr('title', obj.UUID).html(getSubmissionDate(obj.Date)));

            var a = $('<a></a>').css('cursor','pointer').html(obj.Filename).click(function(){
              useSubmission(obj.ID);
            });
            var a2 = $('<a></a>').css('cursor','pointer').html(' (download)').click(function(){
              download(obj.ID, obj.Filename, '');
            });
            var td = $('<td></td>');
            td.append(a);
            td.append(a2);

            r.append(td);

            if (obj.Custom) {
              r.append($('<td></td>').html("N/A"));
            } else {
              var userScore = obj.Score.toLocaleString();
              if ($.inArray(obj.Status, ["Waiting", "Evaluating", "Compiling"]) > -1) {
                userScore = "?";
              }
              r.append($('<td></td>').html(userScore +'/'+ obj.Points.toLocaleString() + (obj.Official ? ' (official)' : '')));
            }

            r.append($('<td></td>').html(obj.Status));

            r.append($('<td></td>').html(obj.Compiler.name));
            t.append(r);
            td = $('<td></td>');
            a = $('<a></a>').html('results').css('cursor','pointer').click({obj:obj}, function(event){
              listSubmissions();
              getSubmissionDetails(event.data.obj.ID);
              modalDialog.dialog("open");
            });
            td.append(a);
            r.append(td);

            t.append(r);
          });

          d.append(t);
          $('<h2></h2>').html('Previous submissions').insertBefore(t);
          $('<div></div>').html('Click file name to reuse submission. NOTE: this will overwrite existing text.').insertBefore(t);
        }
      }
    });
  }

  function getSubmissionDetails(submissionID) {
    modalContainer.find('.detailContainer').html("Loading...");

    $.ajax({
      type: "GET",
      url: "/admin/api/submission/" + submissionID,
      contentType: "application/json",
      dataType: "json",
      data: {
        format: 'details'
      },
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
      },
      success: function (result) {
        modalContainer.find('.detailContainer').remove();

        var detailContainer = $('<div></div>').addClass('detailContainer');
        modalContainer.append(detailContainer);

        var outputCSS = {
          "white-space": "pre",
          "font-family": "monospace",
          "background": "#cacaca",
          "border": "1px solid",
          "border-color": "#b7b3b3",
          "padding": "7px",
          "padding-left": "12px",
          "overflow": "auto"
        };

        if (result.Custom) { // Details for custom submissions
          if (typeof result.stdin === "string") {
            detailContainer.append($('<div></div>').html('Custom input:').css({'font-weight':'bold'}));
            detailContainer.append($('<div></div>').text(result.stdin).css(outputCSS));
          }

          if (result.stdout) {
            detailContainer.append($('<div></div>').html('stdout:').css({'font-weight':'bold'}));
            detailContainer.append($('<div></div>').text(result.stdout).css(outputCSS));
          }

          if (result.stderr) {
            detailContainer.append($('<div></div>').html('stderr:').css('font-weight','bold'));
            detailContainer.append($('<div></div>').text(result.stderr).css(outputCSS));
          }

        } else { //Details for normal submissions
          if (result.stdout) {
            detailContainer.append($('<div></div>').html('stdout:').css({'font-weight':'bold'}));
            detailContainer.append($('<div></div>').text(result.stdout).css(outputCSS));
          }
          if (result.stderr) {
            detailContainer.append($('<div></div>').html('stderr:').css('font-weight','bold'));
            detailContainer.append($('<div></div>').text(result.stderr).css(outputCSS));
          }

          if(!result.stdout && !result.stderr){
            if (!result.testsets.length) {
              detailContainer.append($('<div></div>').css({'margin-left':'10px','font-style':'italic'}).html('No results available yet'))
            } else {
              var headers = ['Testset', 'Outcome', 'Score', 'Testcases', ''];
              var t = $('<table></table>').addClass('submissions').addClass('testData');
              var tr = $('</tr><tr>');
              $.each(headers, function(key,val){
                tr.append($('<th></th>').html(val));
              });
              t.append(tr);
              $.each(result.testsets, function(key,val){
                tr = $('<tr></tr>').css({'vertical-align':'top'});

                //Testset
                tr.append($('<td></td>').html(val.desc));

                var outcome = "Passed";
                $.each(val.evaluations, function(key, val){
                  if(val.status !== 'Ok') {
                    outcome = "Error";
                  }
                });

                //Outcome
                tr.append($('<td></td>').html(outcome));

                //Score
                tr.append($('<td></td>').html(`${val.score} / ${val.points}`));

                //Testcases
                var testcases = $('<td></td>');
                var testcaseStatusses = $('<td></td>');
                $.each(val.evaluations, function(k,evaluation){
                  testcases.append($('<div></div>').html(`Testcase ${k+1}:`));
                  testcaseStatusses.append($('<div></div>').html(evaluation.status));
                });

                tr.append(testcases);
                tr.append(testcaseStatusses);
                t.append(tr);
              });
              detailContainer.append(t);
              t.append(tr)
            }
          }
        }
      }
    });
  }

  function useSubmission(submissionID) {
    $.ajax({
      type: "GET",
      url: "/admin/api/submission/" + submissionID,
      contentType: "application/json",
      dataType: "json",
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
      },
      data: {
        format: 'single'
      },
      success: function(result) {
        updateCodeMirror(result.Source);
        $('#compiler').val(result.Compiler.id);
      }
    });
  }

  function startCodeMirror() {
    CodeMirror.modeURL = "/admin/vendor/npm-asset/codemirror/mode/%N/%N.js";
    return editor = CodeMirror.fromTextArea(
      $("#answer").get(0), {
        lineNumbers: true,
        styleActiveLine: true,
        mode: ""
      }
    );
  }

  function updateCodeMirror(value) {
    editor.getDoc().setValue(value);
  }

  function setEditorMode() {
    m = $('#compiler option:selected').data('mimetype')
    var info = CodeMirror.findModeByMIME(m);
    if (info) {
      mode = info.mode;
      spec = m;
    }
    editor.setOption('mode', spec)
    CodeMirror.autoLoadMode(editor, mode);
  }

  function download(submissionID, filename, text) {
    $.ajax({
      type: "GET",
      url: "/admin/api/submission/" + submissionID,
      contentType: "application/json",
      dataType: "json",
      headers: {
        "cuttle-api-key": api_key,
        "cuttle-session-id": sessionID,
      },
      data: {
        format: 'single'
      },
      success: function(result) {
        text = result.Source;
        var pom = document.createElement('a');
        pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        pom.setAttribute('download', filename);

        if (document.createEvent) {
          var event = document.createEvent('MouseEvents');
          event.initEvent('click', true, true);
          pom.dispatchEvent(event);
        } else {
          pom.click();
        }
      }
    });
  }

});
