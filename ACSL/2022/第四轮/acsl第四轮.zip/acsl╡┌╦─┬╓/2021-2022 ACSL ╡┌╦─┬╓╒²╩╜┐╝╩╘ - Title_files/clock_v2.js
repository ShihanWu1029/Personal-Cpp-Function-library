/* 20170108 - arne@eljakim.nl - (c) 2018 Eljakim IT */

$(document).ready(function() {

  var oldTime = Math.floor(new Date().getTime() / 1000);
  var countdownValue = timeleft;

  //var timeleft = (12 * 60 * 60) + 2;
  var cursor = ['-', '\\', '|', '/'];
  //var time_unit = {d:'d', h:'u', m:'m', s:'s'};
  var timeleft_warning_shown = false;

  var use_ticker = false;
  if (! use_ticker)
    $('#question_clock_ticker').toggle();

  updateClock();
  monitorWarning();
  var intervalID = setInterval(updateClock, 1000);
  var intervalID2 = setInterval(monitorWarning, 1000);

  function monitorWarning() {
    if (countdownValue < timeleft_warning_timeout && ! timeleft_warning_shown) {
      $('#question_titlebar').after(
        $('<div />')
          .prop('id', 'timeleft_warning')
          .text(timeleft_warning)
      );
      timeleft_warning_shown = true;
      clearInterval(intervalID2);
    }
  }

  function updateClock() {

    if (countdownValue <= 0) {
      bebras_clock_display = "00:00";
      bebras_clock_unit = "";
    } else

    if (countdownValue < 60 * 60) {
      minutes = parseInt(countdownValue / 60);
      seconds = parseInt(countdownValue % 60);
      if (seconds < 10)
        seconds = "0" + seconds;
      bebras_clock_display = minutes + ":" + seconds;
      bebras_clock_unit = time_unit.m +":"+ time_unit.s;
    } else

    if (countdownValue < 12 * 60 * 60) {
      hours = parseInt(countdownValue / 60 / 60);
      minutes = parseInt(countdownValue / 60 % 60);
      if (minutes < 10)
        minutes = "0" + minutes;
      bebras_clock_display = hours + ":" + minutes;
      bebras_clock_unit = time_unit.h +":"+ time_unit.m;
    } else

    if (countdownValue < 24 * 60 * 60) {
      bebras_clock_display = parseInt(countdownValue / 60 / 60)
      bebras_clock_unit = time_unit.h
    } else

    if (countdownValue >= 24 * 60 * 60) {
      bebras_clock_display = parseInt(countdownValue / 60 / 60 / 24)
      bebras_clock_unit = time_unit.d
    } else {
      bebras_clock_display = 'anders'
      bebras_clock_unit = "?"
    }

    $('#question_clock_value').text(bebras_clock_display);
    $('#question_clock_unit').text(bebras_clock_unit);
    if (use_ticker)
      $('#question_clock_ticker').text('[' + cursor[countdownValue % 4] + ']');


    var newTime = Math.floor(new Date().getTime() / 1000);
    countdownValue = timeleft - (newTime - oldTime);

    if (countdownValue < 0)
      clearInterval(intervalID);
  }
});
