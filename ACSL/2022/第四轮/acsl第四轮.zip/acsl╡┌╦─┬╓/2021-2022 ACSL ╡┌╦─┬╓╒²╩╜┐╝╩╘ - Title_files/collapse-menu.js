/* 20170108 - arne@eljakim.nl - (c) 2018 Eljakim IT */

/*
    .css({
      'padding':'3px',
      'background':'#fff',
      'float':'left',
      'box-sizing':'border-box',
      'cursor':'pointer',
      'width':'100px',
      'margin-left':'-100px',
      'margin-top':'50px',
      'padding-right':'5px',
      'text-align':'right',
    })
*/

$(document).ready(function() {
  $('#left')
  .before(
    $('<span />')
    .prop('id','toggle')
    .prop('title', i18n_strings.hide_menu)
    .click(function(){
      hide_show();
    })
    .append(
      $('<div />')
      .addClass('text')
      .text(i18n_strings.hide_menu)
    )
    .append(
      $('<div />')
      .addClass('icon')
    )
  );
  function hide_show() {
    $('#left').toggle();
    $('#toggle').toggleClass('active');
    if ($('#left').is(':visible')) {
      $('#toggle').prop('title', i18n_strings.hide_menu);
      $('#toggle .text').text(i18n_strings.hide_menu);
      $('.warning').css('margin-left', '-30px');
      $('#page_content').css('padding-left','210px');
    } else {
      $('#toggle').prop('title', i18n_strings.show_menu);
      $('#toggle .text').text(i18n_strings.show_menu);
      $('.warning').css('margin-left','-10px');
      $('#page_content').css('padding-left','10px');
    }
  }
});
